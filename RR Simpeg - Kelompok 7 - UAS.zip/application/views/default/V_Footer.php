
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright &copy; <?=date('Y');?> Fadhiil Rachman</span>
          </div>
        </footer>
      </div>